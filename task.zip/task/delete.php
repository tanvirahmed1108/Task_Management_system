<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<?php include "db.php"; ?>
<?php
$id = $_GET['id'];
$conn->query("DELETE FROM tasks WHERE id=$id");
header("Location: index.php");
exit();
?>
