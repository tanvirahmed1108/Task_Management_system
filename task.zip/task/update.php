<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<?php include "db.php"; ?>
<?php
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM tasks WHERE id=$id");
$task = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title  = $_POST['title'];
    $desc   = $_POST['description'];
    $status = $_POST['status'];

    $conn->query("UPDATE tasks SET title='$title', description='$desc', status='$status' WHERE id=$id");
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
</head>
<body>
    <h2>Edit Task</h2>
    <form method="POST">
        <label>Title:</label><br>
        <input type="text" name="title" value="<?= $task['title'] ?>" required><br><br>
        <label>Description:</label><br>
        <textarea name="description"><?= $task['description'] ?></textarea><br><br>
        <label>Status:</label><br>
        <select name="status">
            <option <?= $task['status']=="Pending" ? "selected" : "" ?>>Pending</option>
            <option <?= $task['status']=="Completed" ? "selected" : "" ?>>Completed</option>
        </select><br><br>
        <button type="submit">Update Task</button>
    </form>
    <br>
    <a href="index.php">Back</a>
</body>
</html>
