function validateLogin() {
    let user = document.getElementById("username").value.trim();
    let pass = document.getElementById("password").value.trim();

    if (user === "" || pass === "") {
        alert("Both fields are required!");
        return false;
    }
    return true;
}

function validateRegister() {
    let user = document.getElementById("reg_username").value.trim();
    let pass = document.getElementById("reg_password").value.trim();

    if (user === "" || pass === "") {
        alert("Both fields are required!");
        return false;
    }
    if (pass.length < 4) {
        alert("Password must be at least 4 characters long!");
        return false;
    }
    return true;
}

function validateTaskForm() {
    let title = document.getElementById("task_title").value.trim();
    if (title === "") {
        alert("Task title cannot be empty!");
        return false;
    }
    return true;
}
