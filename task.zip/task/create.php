<?php
include "db.php";
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $desc  = $_POST['description'];
    $user_id = $_SESSION['user_id'];

    // Insert into DB
    if ($conn->query("INSERT INTO tasks (title, description, user_id) VALUES ('$title', '$desc', $user_id)")) {
        echo "<script>
            alert('Task added successfully!');
            window.location.href='index.php';
        </script>";
        exit();
    } else {
        echo "<script>alert('Error adding task.');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Task</title>
    <link rel="stylesheet" href="style.css">
    <script src="validate.js"></script>
</head>
<body>
    <h2>Add New Task</h2>
    <form method="POST" onsubmit="return validateTaskForm()">
        <label>Title:</label><br>
        <input type="text" name="title" id="task_title" required><br><br>

        <label>Description:</label><br>
        <textarea name="description"></textarea><br><br>

        <button type="submit">Save Task</button>
    </form>
    <br>
    <a href="index.php">⬅ Back to Task List</a>
</body>
</html>
